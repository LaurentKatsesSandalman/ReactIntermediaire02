import "./App.css";

import UserProfile from "./components/UserProfile";

function App() {
  return <UserProfile />;
}

export default App;