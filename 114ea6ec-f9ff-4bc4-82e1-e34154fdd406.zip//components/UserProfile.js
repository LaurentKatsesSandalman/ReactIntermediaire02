import React from "react";

function UserProfile() {
  return (
    <>
      <p>User is </p>

      <button>click to change user status </button>
    </>
  );
}

export default UserProfile;